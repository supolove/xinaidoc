package com.xh.demo;


import android.content.Context;

import com.lib.xh.sdk.XHApplication;
import com.lib.xh.sdk.XHSDK;
import com.xh.model.XHConfig;

public class MyApplication extends XHApplication {
	Context mContext;
	@Override
	public void onCreate() {
		super.onCreate();
        //初始化sdk
		XHConfig config = new XHConfig();
		config.setLandscape(true);//设置方向 横屏 true 竖屏false
		config.setDebug(true);//设置debug模式,对应测试环境，正式打包时，请修改为false
		XHSDK.getInstance().initApplication(this,config);
	}

}
