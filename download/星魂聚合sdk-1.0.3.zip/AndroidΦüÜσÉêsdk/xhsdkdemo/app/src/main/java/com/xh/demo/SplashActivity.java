package com.xh.demo;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;

import com.lib.xh.sdk.XHSplashActivity;

public class SplashActivity extends XHSplashActivity {

	@Override
	public void onSplashBefore(Context context, Bundle savedInstanceState) {
	}
	
	@Override
	public void onSplashFinish() {
		startActivity(new Intent(SplashActivity.this, GameActivity.class));
		finish();
	}
	
}
