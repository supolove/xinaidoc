package com.xh.demo;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.graphics.Point;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager.LayoutParams;
import android.widget.Button;

public class LoginDialog extends Dialog {
	private Button QQLoginBtn;
	private Button WXLoginBtn;
	private Point point = null;
	private Activity mContext;

	interface LoginDialogListener{
		void onQQClick();
		void onWXClick();
	}

	private LoginDialogListener listener;

	public LoginDialog(Activity context, LoginDialogListener listener) {
		super(context, R.style.LoginDialog);
		this.listener = listener;
		mContext = context;
		point = getWindowSize(context);
		setDlgPosition();
	}

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		initDialog();
	}

	public void setDlgPosition(){
		Window win = getWindow();
		LayoutParams params = new LayoutParams();
		params.x = 0 ;//设置x坐标
		params.y = point.y/4 ;//设置y坐标
		win.setAttributes(params);
	}
	
	private Point getWindowSize(Context context){
		//获取屏幕大小
		DisplayMetrics dm = new DisplayMetrics();
		dm = context.getApplicationContext().getResources().getDisplayMetrics();
		int screenWidth = dm.widthPixels;   
		int screenHeight = dm.heightPixels;
		return new Point(screenWidth,screenHeight);
	}
	
	protected void initDialog(){

		LayoutInflater inflater = LayoutInflater.from(mContext);
		View viewDialog = inflater.inflate(R.layout.xh_login_dialog, null);

		Display display = mContext.getWindowManager().getDefaultDisplay();
		int width = display.getWidth();
		int height = display.getHeight();
		ViewGroup.LayoutParams layoutParams = new  ViewGroup.LayoutParams(width, height);
		//设置dialog的宽高为屏幕的宽高
		setContentView(viewDialog,layoutParams);
		QQLoginBtn = (Button)findViewById(R.id.qqLoginBtn);
		WXLoginBtn = (Button)findViewById(R.id.wxLoginBtn);
		QQLoginBtn.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				listener.onQQClick();
				LoginDialog.this.cancel();
			}
		});
		WXLoginBtn.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				listener.onWXClick();
				LoginDialog.this.cancel();
			}
		});
	}
}
