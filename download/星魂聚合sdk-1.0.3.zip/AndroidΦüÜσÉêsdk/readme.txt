接入前阅读必须阅读

当前版本本
  1.0.3

目录说明
  资源 : 接入需要的资源，拷贝到对应的文件夹
  xhsdkdemo : 接入demo，cp可以参照demo做好接入

sdk接入文档地址
  http://192.168.11.150:4001/androidsdk.html

sdk 自测文档地址
  http://192.168.11.150:4001/android%E8%87%AA%E6%B5%8B%E6%96%87%E6%A1%A3.html

登录校验文档地址
  http://192.168.11.150:4001/user-channel-verify.html

充值回调文档地址
  http://192.168.11.150:4001/server-pay.html
