package com.xh.demo;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.res.Configuration;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.lib.xh.sdk.XHSDK;
import com.xh.callback.XHStateCallBack;
import com.xh.contacts.Constant;
import com.xh.contacts.XHError;
import com.xh.contacts.XHGameAction;
import com.xh.contacts.XHPlatform;
import com.xh.model.XHErrorInfo;
import com.xh.model.pay.XHCpPayInfo;
import com.xh.model.user.XHCpUserInfo;
import com.xh.model.user.XHGotUserInfo;
import com.xh.model.user.XHPlatformSubUserInfo;

public class GameActivity extends Activity implements OnClickListener {

    private XHSDK sdk;
    private RelativeLayout rlContentLogin;
    private  LinearLayout rlContentGame;//游戏登录界面 游戏内容界面

    private Button login, btnPay,logoutBtn;
    private TextView descriptTextView;
    private String userId;
    private String userName;

    private TextView gameTitleTextView;
    private Button enterButton, createRoleButton, roleLevelButton;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.ui_game);
        sdk = XHSDK.getInstance();

        sdk.setStateCallBack(initStateCallback());

        initViews();
        //必须保证游戏运行期间 该activity不被销毁，否则会引起crash
        sdk.initGameActivity(this, "1.0.1");
        sdk.onCreate(this);

        //获取当前使用渠道id 具体id对应渠道请查阅文档
        String channelId = sdk.getChannelId();
        toast("当前渠道id:" + channelId);

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        //必须在发起支付的activity重写onActivityResult,并调用以下方法
        sdk.onActivityResult(this, requestCode, resultCode, data);
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        sdk.onNewIntent(this, intent);
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        sdk.onConfigurationChanged(this, newConfig);
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        sdk.onSaveInstanceState(this, outState);
    }

    @Override
    protected void onResume() {

        sdk.onResume(this);
        super.onResume();
    }

    @Override
    protected void onStart() {
        sdk.onStart(this);
        super.onStart();
    }

    @Override
    protected void onPause() {
        sdk.onPause(this);
        super.onPause();
    }

    @Override
    protected void onStop() {
        sdk.onStop(this);
        super.onStop();
    }

    @Override
    protected void onRestart() {
        sdk.onRestart(this);
        super.onRestart();
    }

    @Override
    protected void onDestroy() {
        sdk.onDestroy(this);
        super.onDestroy();
    }

    @Override
    public void onBackPressed() {
        // 退出游戏
        if (sdk.hadPlatformQuitUI()){
            sdk.quit(this);
        }else{
            //此处可以使用游戏自身的退出ui
            new AlertDialog.Builder(this).setTitle("模拟游戏的退出UI\n确认退出游戏？")
                    .setPositiveButton("确定", new DialogInterface.OnClickListener() {

                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            // 回收sdk资源
                            sdk.destroySDK(GameActivity.this);
                            GameActivity.this.finish();
                            System.exit(0);
                        }
                    })
                    .setNegativeButton("取消", new DialogInterface.OnClickListener() {

                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                        }
                    }).show();
        }
    }

    private void initViews() {
        rlContentLogin = (RelativeLayout) findViewById(R.id.rl_content_login);
        rlContentGame = (LinearLayout) findViewById(R.id.rl_content_game);
        login = (Button) findViewById(R.id.login);
        btnPay = (Button) findViewById(R.id.pay);
        descriptTextView = (TextView) findViewById(R.id.game);
        gameTitleTextView = (TextView)  findViewById(R.id.game_title);
        logoutBtn = (Button) findViewById(R.id.logout);
        enterButton = (Button) findViewById(R.id.enter_server);
        createRoleButton = (Button) findViewById(R.id.creat_role);
        roleLevelButton = (Button) findViewById(R.id.role_level);
        login.setOnClickListener(this);
        btnPay.setOnClickListener(this);
        logoutBtn.setOnClickListener(this);
        enterButton.setOnClickListener(this);
        createRoleButton.setOnClickListener(this);
        roleLevelButton.setOnClickListener(this);
    }

    @Override
    public void onClick(View arg0) {
        switch (arg0.getId()) {
            case R.id.login:
                //应用宝登录，请判断当前的channelId是否为 ："ysdk" 并使用login2接口
                if (TextUtils.equals("ysdk",(sdk.getChannelId()))){
                    // 应用宝提供微信或qq登陆
                    // qq按钮和微信按钮可以放在游戏中,效果会更好，以免使用以下方法弹框显示登录按钮
                    LoginDialog dialog = new LoginDialog(this, new LoginDialog.LoginDialogListener() {
                        @Override
                        public void onQQClick() {
                            login2(XHPlatform.QQ);
                        }

                        @Override
                        public void onWXClick() {
                            login2(XHPlatform.WX);
                        }
                    });
                    dialog.show();
                } else {
                    // 普通渠道登陆
                    login();
                }
                break;
            case R.id.pay:
                pay(getPayInfo());
                break;
            case R.id.logout:
                // 游戏主动调用登出
                sdk.logout(this);
                break;
            case R.id.enter_server:
                subUserInfo(XHGameAction.ENTER_SERVER);
                break;

            case R.id.creat_role:
                subUserInfo(XHGameAction.CREATE_ROLE);
                break;
            case R.id.role_level:
                subUserInfo(XHGameAction.LEVEL_UP);
                break;
            default:
                break;
        }
    }

    private void login() {
        sdk.login(GameActivity.this);
    }

    private void login2(XHPlatform platform) {
        sdk.login2(GameActivity.this, platform);
    }

    private void subUserInfo(XHGameAction action) {
        // 提交游戏用户信息
        //提交游戏用户信息
        XHPlatformSubUserInfo.Builder info = new XHPlatformSubUserInfo.Builder();
        info.setPower(0)
                .setProfessionId(101)//登陆角色的职业ID，如无请填写：0
                .setProfession("魔法师")//登陆角色的职业名称，如无请填写"无"
                .setGuildName("第一公会")//当前角色所属帮派帮派名称，如无请填写：无
                .setGuildId(1001)//当前角色所属帮派帮派Id，如无请填写:0
                .setGuildTitleId(1)//角色在帮派中的帮派称号Id,帮主则必填：1，其他可自定义，如无请填写：0
                .setGuildTitleName("帮主")//角色在帮派中的帮派称号,如无请填写："无"
                .setGender("男")//登陆角色的性别，不能为空，可选：“男、女、无”
                .setServerId(1)//服务器Id
                .setServerName("测试一区")//服务器名称
                .setUserId(userId) // 登录接口返回用户ID
                .setUserName(userName)
                .setRoleName("测试角色")//当前角色昵称
                .setRoleId("123456789")//v1.1.0新增 角色ID
                .setRoleLevel("10")//当前角色等级
                .setRoleCTime(1000000000L)//角色创建时间(单 位:秒),长度 10, 获取服务器存储 的时间,不可用手机本地时间
                .setVipLevel("6");//当前用户的VIP等级，如无请填写：0
        descriptTextView.setText(info.toString());
        if (action == XHGameAction.ENTER_SERVER){
            descriptTextView.setText("进入游戏服务器上报：\n" + info.toString());
        }else if (action == XHGameAction.CREATE_ROLE){
            descriptTextView.setText("创建角色上报：\n" + info.toString());
        }else if (action == XHGameAction.LEVEL_UP){
            descriptTextView.setText("角色等级上报：\n" + info.toString());
        }
        sdk.submitUserInfo(GameActivity.this, action, info.build());
    }


    private XHCpPayInfo getPayInfo() {
        XHCpUserInfo.Builder userBuild = new XHCpUserInfo.Builder();
        userBuild.setRoleName("测试角色")
                .setRoleId("1234560")//当前登陆的角色ID
                .setUserId(userId)// 登录接口返回用户ID
                .setRoleLevel("10")// 角色等级
                .setVipLevel("6")// vip等级
                .setBalance("0");// 余额 rmb 单位：元

        XHCpPayInfo.Builder payBuild = new XHCpPayInfo.Builder();
        payBuild.setCpUserInfo(userBuild.build())
                .setCpOrderId(System.currentTimeMillis() + "")// 订单号 此处以随机数代替
                .setAmount(100)// rmb 单位：分
                .setRatio(10)// 交易比率，如1元＝10元宝，比率请填写10,默认为1:1  即1元＝1元宝
                .setProductName("钻石")// 商品名
                .setCount(1)
                .setProductId("com.yyshouyou.sgdh.6")// 商品id
                .setAppName("测试游戏01")// 游戏名
                .setServerId("20")// 修改此参数为必选参数 游戏服务器id，最长10位
                .setServerName("测试一区")
                .setExtraData("extra_info");// (可选参数) CP 扩展信息

        return payBuild.build();
    }

    private void pay(XHCpPayInfo cpPayInfo) {
        sdk.doPayBySDK(this,cpPayInfo);
    }

    /**
     * //提交礼包码，如游戏有礼包兑换功能即必接
     *
     * @param giftCode
     */
    private void submitGiftCode(String giftCode) {
        sdk.submitGiftCode(this, giftCode);
    }

    private void toast(final String msg) {
        GameActivity.this.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                Toast.makeText(GameActivity.this, msg, Toast.LENGTH_SHORT).show();
            }
        });
    }


    private void toGameContent(){
        rlContentLogin.setVisibility(View.GONE);
        rlContentGame.setVisibility(View.VISIBLE);
    }

    private void returnGameLogin(){
        rlContentLogin.setVisibility(View.VISIBLE);
        rlContentGame.setVisibility(View.GONE);
    }


    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (sdk != null){
//            sdk.onRequestPermissionsResult(this,requestCode,permissions,grantResults);
        }
    }

    private static final String TAG = "initStateCallback";

    private XHStateCallBack initStateCallback(){
        return new XHStateCallBack() {

            @Override
            public void onInitSuccess() {
                Log.d(TAG, "onInitSuccess: ");
            }

            @Override
            public void onInitFail(XHErrorInfo xhErrorInfo) {
                Log.d(TAG, "onInitFail: ");
            }

            @Override
            public void onLoginSuccess(XHGotUserInfo userInfo) {
                Log.d(TAG, "onLoginSuccess: ");
                //进入游戏
                toGameContent();
                // sdk返回的用户ID 支付时需传入
                userId = userInfo.getUid() + "";
//            // 校验用户有效性需使用
                String secretKey = userInfo.getSecretKey();
//            toast("登录成功\n" + accessToken);
                gameTitleTextView.setText("游戏页面userId:" + userId);
            }

            @Override
            public void onLoginFail(XHErrorInfo xhErrorInfo) {
                Log.d(TAG, "onLoginFail: " + xhErrorInfo.getErrorMsg());
                switch (xhErrorInfo.getErrorCode()) {
                    case XHError.CODE_LOGIN_CANCEL:
                        // 登陆取消
                        break;
                    case XHError.CODE_LOGIN_LOADING:
                        // 正在登陆
                        break;
                    case XHError.CODE_USER_INVALID:
                        //登陆失败XHError.CODE_USER_INVALID返回,请厂商在收到此返回时把游戏退出到首页，否则测试不会通过，谢谢合作！
                        returnGameLogin();
                        break;
                    default:
                        // 其他异常
                        break;
                }
                toast(xhErrorInfo.getErrorMsg());
            }

            @Override
            public void onLogoutSuccess() {
                Log.d(TAG, "onLogoutSuccess: ");
                returnGameLogin();
            }

            @Override
            public void onLogoutFail(String errorMessage) {
                Log.d(TAG, "onLogoutFail: " + errorMessage);
            }

            @Override
            public void onPaySuccess(String orderId) {
                // 此时CP可记录订单编号，提交给后台服务器，等待到账通知，如果到账即可发货
                toast("已发起支付，请查询服务器是否到账" + orderId);
                Log.d(TAG, "onPaySuccess: ");
            }

            @Override
            public void onPayFail(XHErrorInfo xhErrorInfo) {
                Log.d(TAG, "onPayFail: " );
                switch (xhErrorInfo.getErrorCode()) {
                    case XHError.CODE_WITHOUT_LOGIN:
                        // 尚未登陆
                        break;
                    case XHError.CODE_NEED_LOGIN_AGAIN:
                        // 需要重新登陆
                        break;
                    case XHError.CODE_PAY_CANCEL:
                        // 支付取消
                        break;
                    case XHError.CODE_IN_PAYMENT:
                        // 正在付款
                        break;
                    default:
                        // 其他异常
                        break;
                }
                toast(xhErrorInfo.getErrorMsg());
            }

            @Override
            public void onQuit() {
                Log.d(TAG, "onQuit: ");
                // 回收sdk资源
                sdk.destroySDK(GameActivity.this);
                GameActivity.this.finish();
                System.exit(0);
            }

            @Override
            public void onSwitchAccountSuccess(XHGotUserInfo userInfo) {
                Log.d(TAG, "onSwitchAccountSuccess: ");
                // 切换登录成功
                // 进入游戏
                toGameContent();
                userId = userInfo.getUid() + "";
                userName = userInfo.getUsername();
                toast("悬浮窗:切换账号登录成功");
                gameTitleTextView.setText("游戏页面userId:" + userId);
            }

            @Override
            public void onSwitchAccountFail(String erroe) {
                Log.d(TAG, "onSwitchAccountFail: ");
                // 请厂商在收到此返回时把游戏退出到首页，否则测试不会通过，谢谢合作！
                // 返回登录界面
                returnGameLogin();
            }
        };
    }
}
