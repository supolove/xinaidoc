package com.xh.demo;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;

import com.lib.xh.sdk.XHSplashActivity;

public class SplashActivity extends XHSplashActivity {

	@Override
	protected void onSplashBefore(Context context, Bundle savedInstanceState) {
	}
	
	@Override
	protected void onSplashFinish() {
		startActivity(new Intent(SplashActivity.this, GameActivity.class));
		finish();
	}
	
}
