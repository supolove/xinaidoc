接入前阅读必须阅读

当前版本
  1.0.1

目录说明
  资源 : 接入需要的资源，拷贝到对应的文件夹
  Demo : 接入demo，cp可以参照demo做好接入

SDK接入文档地址
  http://192.168.11.150:4001/iossdk.html

登录校验文档地址
  http://192.168.11.150:4001/user-channel-verify.html
充值回调文档地址
  http://192.168.11.150:4001/server-pay.html
