//
//  SampleViewController.m
//  XAISDKDemo(New)
//
//  Created by XAI-Mac-Andy on 2019/1/18.
//  Copyright © 2019 XAI-Mac-Andy. All rights reserved.
//

#import "SampleViewController.h"
#import <XAIGameSDK/XAIGameSDK.h>


@interface SampleViewController ()<UITableViewDelegate, UITableViewDataSource>

/// 列表
@property (nonatomic, weak) UITableView *tableView;

/// 登出按钮
@property (nonatomic, weak) UIButton *logoutBtn;

@end 

@implementation SampleViewController

- (void)viewWillTransitionToSize:(CGSize)size withTransitionCoordinator:(id<UIViewControllerTransitionCoordinator>)coordinator {
    
    [self setupSubviewsByScreenSize:size];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.view.backgroundColor = [UIColor lightGrayColor];
    
    [self setupSubviewsByScreenSize:UIScreen.mainScreen.bounds.size];
    
    [XHSDK shareSDK].switchAccountBlock = ^{
        
        [self.navigationController popViewControllerAnimated:YES];
    };
}

- (BOOL)prefersStatusBarHidden {
    return YES;
}

- (void)setupSubviewsByScreenSize:(CGSize)screenSize {
    
    CGFloat bottomMargin = 60;
    CGFloat
    curScreenW = screenSize.width,
    curScreenH = screenSize.height;
    CGRect rect = CGRectMake(0, 0, curScreenW, curScreenH - bottomMargin);
    self.tableView.frame = rect;
    [self.view addSubview:self.tableView];
    
    if (!_logoutBtn) {
        
        UIButton *logoutBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        _logoutBtn = logoutBtn;
        [self.view addSubview:logoutBtn];
        [logoutBtn setBackgroundColor:[UIColor redColor]];
        [logoutBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        [logoutBtn setTitle:@"登出" forState:UIControlStateNormal];
        logoutBtn.titleLabel.font = [UIFont systemFontOfSize:19];
        logoutBtn.center = CGPointMake(self.view.center.x, self.view.center.y - 80);
        [logoutBtn addTarget:self action:@selector(actionLogout) forControlEvents:UIControlEventTouchUpInside];
    }
    CGFloat
    marginSide = 40,
    logoutBtnW = curScreenW - 2 * marginSide,
    logoutBtnH = 40;
    _logoutBtn.frame = CGRectMake(marginSide, CGRectGetMaxY(self.tableView.frame) + 10, logoutBtnW, logoutBtnH);
}

- (UITableView *)tableView {
    
    if (!_tableView) {
        
        UITableView *tableV = [[UITableView alloc] initWithFrame:CGRectZero style:UITableViewStyleGrouped];
        tableV.dataSource = self;
        tableV.delegate = self;
        _tableView = tableV;
        [self.view addSubview:tableV];
    }
    return _tableView;
}
#pragma mark - <UITableViewDelegate, UITableViewDataSource>
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 2;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    if (section == 0) {
        return 1;
    } else {
        return 3;
    }
}
 static NSString * const reuseID = @"SampleCellID";
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:reuseID];
    if (!cell) {
        
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:reuseID];
    }
    NSString *title = nil;
    if (indexPath.section == 0) {
        
        if (indexPath.row == 0) {
            
            title = @"进入游戏服务器";
        }
    } else if (indexPath.section == 1) {
        
        title = [NSString stringWithFormat:@"测试商品%ld", indexPath.row + 1];
    } else {
        
    }
    cell.textLabel.text = title;
    return cell;
}
- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section {
    
    NSString *title = nil;
    if (section == 0) {
        title = @"基础功能";
    } else {
        title = @"内购测试";
    }
    return title;
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    
    if (indexPath.section == 0) {
        
        if (indexPath.row == 0) {
            
            [self actionLoginServer];
        }
    } else if (indexPath.section == 1) {
        
        if (indexPath.row == 0) {
            
            [self IAP_CpProductID:@"CpProduct1"];
        } else if (indexPath.row == 1) {
            
            [self IAP_CpProductID:@"CpProduct2"];
        } else {
            
            [self IAP_CpProductID:@"CpProduct3"];
        }
    } else {
        
    }
}

- (void)actionLogout {
    
    [[XHSDK shareSDK] logoutCompletion:^(BOOL result) {
        
        NSString *logoutResult = result ? @"退出登录成功" : @"退出登录失败";
        NSLog(@"%@", logoutResult);
        [self.navigationController popViewControllerAnimated:YES];
    }];
}

static NSString * const _roleName = @"XO人头马";
static NSString * const _roleID = @"10000000";
static NSString * const _serverID = @"testID";
static NSString * const _serverName = @"AppleTestServer";

- (void)IAP_CpProductID:(NSString *)cpProduct {
    
    NSTimeInterval curTime = [[NSDate date] timeIntervalSince1970];
    NSMutableDictionary *parameters = [NSMutableDictionary dictionary];
    parameters[PurchaseKeyRoleID] = _roleID;
    parameters[PurchaseKeyRoleName] = _roleName;
    parameters[PurchaseKeyRoleLevel] = @"200";
    parameters[PurchaseKeyServerID] = _serverID;
    parameters[PurchaseKeyServerName] = _serverName;
    parameters[PurchaseKeyCpOrderID] = @(@(curTime).intValue).stringValue;
    parameters[PurchaseKeyCpProductID] = cpProduct;
    parameters[PurchaseKeyCpExtension] = @"testCpExtension";
    parameters[PurchaseKeyExtension] = @"extension";
    
    [[XHSDK shareSDK] purchaseWithParams:parameters completion:^(SKPaymentTransactionState state, NSError * _Nonnull error) {
        
        NSString *msg = error.localizedDescription;

        if (state == SKPaymentTransactionStatePurchased) {
            
            UIAlertController *alertC = [UIAlertController alertControllerWithTitle:@"交易成功" message:nil preferredStyle:UIAlertControllerStyleAlert];
            [alertC addAction:[UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:nil]];
            [self presentViewController:alertC animated:YES completion:nil];
        } else {
            
            NSLog(@"交易失败, %@", msg);
        }
    }];
}

- (void)actionLoginServer {
    
    [[XHSDK shareSDK] loginGameServer:_serverID serverName:_serverName roleName:_roleName roleId:_roleID completion:^(BOOL result) {
       
        NSString *title = result ? @"角色登录成功" : @"角色登录失败";
        NSLog(@"%@", title);
    }];
}



@end
