//
//  ViewController.m
//  XAIGameSDKDemo
//
//  Created by XAI-Mac-Andy on 2019/2/20.
//  Copyright © 2019 XAI-Mac-Andy. All rights reserved.
//

#import "ViewController.h"
#import "SampleViewController.h"
#import <XAIGameSDK/XAIGameSDK.h>



@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    self.navigationController.navigationBarHidden = YES;
    self.view.backgroundColor = [UIColor lightGrayColor];
}


- (IBAction)GoToLoginExtranet:(id)sender {
    
    [self loginInOption];
}


- (void)loginInOption {
    
    XHSDK *sdk = [XHSDK shareSDK];
    
    NSString
    *appID = nil,
    *appKey = nil;
    
    appID  = @"6oOn1L7ESryH7x4EHg";
    appKey = @"3W2vUtC7Eoy2Jz9kV58r391UdmmTizbh";
    
    [sdk SDKInitWithAppID:appID appKey:appKey channelID:@"xinghun_apple" channelName:@"星魂苹果" versionPackage:@"packVersion" completion:^(BOOL result) {
        
        if (result) {
            
            [sdk showLoginWindow];
        }
    }];
    
    sdk.loginBlock = ^(BOOL result, NSDictionary *userInfo) {
        
        NSString *loginResult = result ? @"登录成功" : @"登录失败";
        NSLog(@"%@", loginResult);
        NSLog(@"用户信息：%@", userInfo);
        if (result) {
            
            SampleViewController *sampleVC = [[SampleViewController alloc] init];
            [self.navigationController pushViewController:sampleVC animated:NO];
        }
    };
}

@end
