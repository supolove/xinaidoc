//
//  AppDelegate.h
//  XAIGameSDKDemo
//
//  Created by XAI-Mac-Andy on 2019/2/20.
//  Copyright © 2019 XAI-Mac-Andy. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

