//
//  SampleNavigationController.h
//  XAIGameSDKDemo
//
//  Created by XAI-Mac-Andy on 2019/3/13.
//  Copyright © 2019 XAI-Mac-Andy. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface SampleNavigationController : UINavigationController

@end

NS_ASSUME_NONNULL_END
