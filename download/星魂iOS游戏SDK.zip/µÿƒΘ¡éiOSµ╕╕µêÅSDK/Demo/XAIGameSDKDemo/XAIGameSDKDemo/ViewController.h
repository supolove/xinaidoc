//
//  ViewController.h
//  XAIGameSDKDemo
//
//  Created by XAI-Mac-Andy on 2019/2/20.
//  Copyright © 2019 XAI-Mac-Andy. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

