//
//  SampleNavigationController.m
//  XAIGameSDKDemo
//
//  Created by XAI-Mac-Andy on 2019/3/13.
//  Copyright © 2019 XAI-Mac-Andy. All rights reserved.
//

#import "SampleNavigationController.h"

@interface SampleNavigationController ()

@end

@implementation SampleNavigationController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}


@end
