//
//  XHOtherLoginManager.h
//  XAISDKDemo(New)
//
//  Created by XAI-Mac-Andy on 2019/1/27.
//  Copyright © 2019 XAI-Mac-Andy. All rights reserved.
//

#import <Foundation/Foundation.h>


NS_ASSUME_NONNULL_BEGIN

#pragma mark - <----------- XHOtherLoginParams ----------->

@interface XHOtherLoginParams : NSObject

/// 账号类型 3-QQ注册 4-wx注册
@property (nonatomic, assign) NSInteger accountType;
/// QQ的openID
@property (nonatomic, copy) NSString *QQOpenID;
/// QQ登录访问token
@property (nonatomic, copy) NSString *QQAccessToken;
/// QQ的token过期时间
@property (nonatomic, copy) NSString *QQExpiresTime;
/// 微信code
@property (nonatomic, copy) NSString *wxCode;

@end

#pragma mark - <----------- XHOtherLoginManager ----------->

@interface XHOtherLoginManager : NSObject

+ (instancetype)shareInstance;

/// 第三方登录配置
- (BOOL)XHHandleOpenURL:(NSURL *)url;

/// 微信登录授权
- (void)XHWechatLogin;
/// QQ登录授权
- (void)XHQQLogin;

/// 授权结果回调
@property (nonatomic, copy) void (^XHOtherLoginHandler)(BOOL result, NSString *msg, XHOtherLoginParams * _Nullable params);

@end

NS_ASSUME_NONNULL_END
