//
//  XAIGameSDK.h
//  XAIGameSDK
//
//  Created by XAI-Mac-Andy on 2019/2/20.
//  Copyright © 2019 XAI-Mac-Andy. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for XAIGameSDK.
FOUNDATION_EXPORT double XAIGameSDKVersionNumber;

//! Project version string for XAIGameSDK.
FOUNDATION_EXPORT const unsigned char XAIGameSDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <XAIGameSDK/PublicHeader.h>


#import <XAIGameSDK/XHSDK.h>
#import <XAIGameSDK/XHOtherLoginManager.h>
