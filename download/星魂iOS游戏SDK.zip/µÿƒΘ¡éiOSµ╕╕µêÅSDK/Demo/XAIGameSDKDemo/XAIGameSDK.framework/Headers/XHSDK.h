//
//  XHSDK.h
//  XAISDK
//
//  Created by XAI-Mac-Andy on 2019/1/17.
//  Copyright © 2019 XAI-Mac-Andy. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <StoreKit/StoreKit.h>


NS_ASSUME_NONNULL_BEGIN

typedef NSString * const PurchaseKey;
/// 角色ID
extern PurchaseKey PurchaseKeyRoleID;
/// 角色名称
extern PurchaseKey PurchaseKeyRoleName;
/// 角色等级
extern PurchaseKey PurchaseKeyRoleLevel;
/// 角色登录的服务器ID
extern PurchaseKey PurchaseKeyServerID;
/// 角色登录的服务器名称
extern PurchaseKey PurchaseKeyServerName;
/// cp的商品ID
extern PurchaseKey PurchaseKeyCpProductID;
/// cp的订单ID
extern PurchaseKey PurchaseKeyCpOrderID;
/// cp的扩展信息
extern PurchaseKey PurchaseKeyCpExtension;
/// 额外的扩展信息
extern PurchaseKey PurchaseKeyExtension;

@interface XHSDK : NSObject

+ (instancetype)shareSDK;

/// 初始化方法
- (void)SDKInitWithAppID:(NSString *)appID
                  appKey:(NSString *)appKey
               channelID:(NSString *)channelID
             channelName:(NSString *)channelName
          versionPackage:(NSString *)versionPg
              completion:(void (^)(BOOL result))handler;

/// 调出登录窗口
- (void)showLoginWindow;

/// 登录的回调
@property (nonatomic, copy) void (^loginBlock)(BOOL result, NSDictionary *userInfo);

/// 登出
- (void)logoutCompletion:(void (^)(BOOL result))handler;

/// 切换账号的回调
@property (nonatomic, copy) void (^switchAccountBlock)(void);

/// 进入游戏服务器
- (void)loginGameServer:(NSString *)serverID
             serverName:(NSString *)serverName
               roleName:(NSString *)roleName
                 roleId:(NSString *)roleID
             completion:(void(^)(BOOL result))handler;

/// 内购支付
- (void)purchaseWithParams:(NSDictionary<PurchaseKey, NSString *> *)params
                completion:(void(^)(SKPaymentTransactionState state, NSError *error))handler;

@end



NS_ASSUME_NONNULL_END
